function [a0,a1]=aproxlin(x,y)
% Calcula la mejor aproximación lineal n el sentido de cuadrados mínimos de los pares (x,y)

m=length(x);
sumx=0;
sumy=0;
sum2x=0;
sumxy=0;

for i=1:m
	t=x(i);
	sumx=sumx+t;
	p=y(i);
	sumy=sumy+p;
	tp=t*p;
	sumxy=sumxy+tp;
	t2=t*t;
	sum2x=sum2x+t2;

endfor

a0=(sum2x*sumy-sumx*sumxy)/(m*sum2x-sumx*sumx);
a1= (m*sumxy-sumx*sumy)/(m*sum2x-sumx*sumx);

end
