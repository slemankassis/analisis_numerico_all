function w=lagrange(x,y,z)
% Evalúa el polinomio interpolante de lagrange en el vector z
% Donde y cumple p(x)=y

w=[];
for i=1:length(z)
	a=z(i);
	p=0;
	for j=1:length(x)
		lj=1;
		for k=1:length(x)
			if k~=j
				lj=lj*(a-x(k))/(x(j)-x(k));
			else
				lj=lj;
			endif
		endfor
		p=p+y(j)*lj;		
	endfor
	w=[w,p];
endfor

end
