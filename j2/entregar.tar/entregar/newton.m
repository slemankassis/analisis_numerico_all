function [hx,hf]=newton(fun,x0,e,m)
% Implementa el método de Newton para encontrar raíces de funciones
% fun debe ser una función derivable de R a R2 que dado x siempre retorna fun(x) y fun'(x)
% por ejemplo [f(x),f'(x)]=fun(x)
% x0 es algún número real
% e es la tolerancia para el error en los valores funcionales
% m es el número máximo de iteraciones permitidas

hx=[];
hf=[];
	
[v1,v2]=feval(fun,x0); %fun debe dar siempre dos argumentos de salida, pero por ejemplo la función fp2ej5 otorga sólo uno pues necesito introducir p=[1,1] para que me dé fp2ej5(x1) y fp2ej5'(x1). Para que este algoritmo funcione con esta función en particular, esta línea debe ser [v1,v2]=feval(fun,x0,[1,1]). Sin embargo dejé el algoritmo así para no perder generalidad.

if abs(v1)<e
	[hx,hf]=[x0,v1];
else
	for k=1:m
		x1=x0-(v1/v2); 
		[v1,v2]=feval(fun,x1); %Al igual que antes debo cambiar por [v1,v2]=feval(fun,x1,[1,1]) para la función fp2ej5 en particular.
		hx=[hx,x1];
		hf=[hf,v1];
		
		if abs(v1)<e
			return
		elseif	 abs(x1-x0)/abs(x1)<e
			return

		else 
			x0=x1;
		endif
	endfor
endif

end
