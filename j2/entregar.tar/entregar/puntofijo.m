function [hx]=puntofijo(fun,x0,e,m)

%Implementa el algoritmo de iteración de Punto Fijo para encontrar puntos fijos de funciones
% fun es la función de R a R a la cual le quiero encontrar un punto fijo
% x0 es la aproximación inicial
% e es la tolerancia para el error
% m es el número máximo de iteraciones

hx=[];
x1=x0;

for k=1:m
    y=feval(fun,x1);
    hx=[hx,y];
   
    if abs(x1-y)<e
        return
    else
        x1=y;
    endif
endfor

end
