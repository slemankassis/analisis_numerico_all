function [hx,hf]=bisec(fun,I,e,M)
% Implementa el método de bisección para encontrar raíces de funciones
%  fun es la función de R a R a la cual le quiero encontrar una raíz
% I es un vector 1x2, I=[a,b], donde a y b son los extremos del intervalo
% e es la tolerancia para el error en los valores funcionales
% m es el número máximo de iteraciones permitidas

a=I(1);
b=I(2);
u=feval(fun,a);
v=feval(fun,b);
E=b-a;
hx=[];
hf=[];

if sign(u)==sign(v)
	disp('elegir otro intervalo, a y b tienen igual signo')
else 
	for k=1:M
		E=E/2;
		c=a+E;
		w=feval(fun,c);
		hx=[hx,c];
		hf=[hf,w];
	
		if abs(w)<e
			return
		else
			if sign(u)~=sign(w)
				b=c;
				v=w;
			else 
				a=c;
				u=w;
			endif
		endif
	endfor

end

