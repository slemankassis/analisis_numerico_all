function [x1,x2]=buena(a,b,c)
%forma correcta de sacar las raíces de un polinomio cuadrático

dis=b^2-4*a*c;

if b>=0
	x1=(2*c)/(-b-sqrt(dis));
	x2=(-b-sqrt(dis))/(2*a);
elseif b<0
	x1=(-b+sqrt(dis))/(2*a);
	x2=(2*c)/(-b+sqrt(dis));

end
