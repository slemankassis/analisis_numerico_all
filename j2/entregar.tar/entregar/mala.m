function [x1,x2]=mala(a,b,c)

x1=(-b-sqrt(b*b-4*a*c))/(2*a);
x2=(-b+sqrt(b*b-4*a*c))/(2*a);

end
