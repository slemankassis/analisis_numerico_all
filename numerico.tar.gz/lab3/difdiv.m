function a = difdiv(f,x)
    l = length(x);
    a = difdiv(f, x[2..]
end
