function y = u(x)
    y = e ^-(1-x*y)^2
end
