function y = lab2_ej2b(x)
    y = x.^2 -3;
end
