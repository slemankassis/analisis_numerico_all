function y = lab2_ej2a(x)
	y = tan(x) - 2*x;
end
