function y = gx(x)
    y = atan(2*x);
end
