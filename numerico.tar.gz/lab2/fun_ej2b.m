function y = fun_ej2b(x)
    y = x^2 -3;
end
