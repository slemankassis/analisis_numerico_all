function y=cuad(x)
	y= atan(x);
end
