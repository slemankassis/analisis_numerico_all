function S=senint

xd = [];
Sd = [];

for x=0.1:0.5:2*pi
 xd = [xd x];
 n=ceil(x/0.1);
 S=intenumcomp(@fun_ej3,0,x,n,'trapecio');
 Sd = [Sd S];

end

plot(xd,Sd,"*",xd,sin(xd),"-")
