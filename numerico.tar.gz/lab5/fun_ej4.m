function y=fun_ej4 (t)

global x
y=1./sqrt(1-(x.^2)*sin(t).^2);
end
