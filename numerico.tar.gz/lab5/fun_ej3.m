function y=fun_ej3(x)

y= cos(x);
end
