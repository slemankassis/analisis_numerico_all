function y=fun_ej2(x)

y= e.^(-x);
end
