function S=intenumcomp(fun,a,b,n,regla)

h=(b-a)/n;
x=[a:h:b];
y=fun(x);

if a==b
	S=0;
return
end

switch regla
	case {"pm"}
	S=2*h*sum(y(2:2:n));
	case {"trapecio"}
	S=(h/2)*(y(1)+2*sum(y(2:n))+y(n+1));
	case {"simpson"}
	S=(h/3)*(y(1)+2*sum(y(3:2:n-1))+4*sum(y(2:2:n))+y(n+1));
end

