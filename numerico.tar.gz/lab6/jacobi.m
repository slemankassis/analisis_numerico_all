function [x,k]=jacobi(A,b,x0,e,m)

n=length(b);
N=A-diag(diag(A));
k=1;
while k<m
	for i=1:n
		c=0;
		for j=1:n
			c=c+N(i,j)*x0(j);
		end		
		x(i,1)=(b(i)-c)/A(i,i);
	end
	if norm(x-x0,inf)<e
		return
	end
	k=k+1;
	x0=x;
end
x=x0;
disp("Se alcanzó el máximo de iteraciones")
