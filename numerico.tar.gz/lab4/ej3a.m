load 'datos3a.mat'

y_1=log(y);
x_1=log(x);
p=polyfit(x_1,y_1,1)
c=exp(p(2));
A=p(1);
plot(x,y,x,c*x.^A)
