function x = cuadmin
load datos1a.mat

n = length(xd);

for i = 1:n
    A(i,1) = 1;
    A(i,2) = xd(i);
end
b = yd
x = A\b'

p = x(1) + x(2)*xd
plot(xd,yd,'-',xd,p,'-')
legend('datos','aproximacion')
end
