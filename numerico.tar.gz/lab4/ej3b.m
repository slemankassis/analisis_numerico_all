load 'datos3b.mat'

y_1=1./y;
x_1=1./x;
p=polyfit(x_1,y_1,1)
A=p(1);
B=p(2);
plot(x,y,x,A*x+B)
