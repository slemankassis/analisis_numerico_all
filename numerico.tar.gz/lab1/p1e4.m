function p1e4
        x = 0;
        while x<10
                x = x + 0.1
        end
end

