function p1e7(a,b)
        a^b
end

