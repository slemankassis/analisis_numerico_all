function fac(n)
        i=0;
        a=1;
        for i=1:n
            a=a*(i);
        end
        a
end

