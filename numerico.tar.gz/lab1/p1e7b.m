function p1e7b(a,b)        
        p1e7(a,b)        
        for i=1:5
                a^i
        end
end
