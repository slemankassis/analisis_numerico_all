function blabla(a)
    s=0;
    b=0;
    while (1!= isinf(b))
            b=2^s;
            s=s+1;
    end
    isinf(b)
    s
    b
end

