function p1e6(a,b)
        if a<b
                b
        else if b<a
                a
        else 
                a=b
        end
end
